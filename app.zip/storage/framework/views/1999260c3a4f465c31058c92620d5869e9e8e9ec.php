<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Home</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                            <a href="/login" class="btn btn-primary ">Login</a>
                        </div>
                    <?php endif; ?>
                    Welcome <?php echo e(Auth::user()->name); ?> to our app
                        <br>
                <a href="/courier" class="btn btn-primary">Go to the app</a>
                </div>
            </div>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum commodi qui perferendis ea praesentium enim, vero, nobis illo nihil tenetur eaque dolorum eos officiis! Suscipit unde impedit sequi accusamus debitis?
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/lcorp/web/speedB/resources/views/home.blade.php ENDPATH**/ ?>