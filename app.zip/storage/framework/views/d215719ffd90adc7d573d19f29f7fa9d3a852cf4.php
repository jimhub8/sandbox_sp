<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="user" content="Auth::user()">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    

    
    
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    

    <!-- Fonts -->
    
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    
    <link href='https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons' rel="stylesheet">
     <link href="https://unpkg.com/vuetify/dist/vuetify.min.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, minimal-ui">
    
 
      
    <!-- Styles -->

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/vueDash.css')); ?>" rel="stylesheet">
    
    
</head>
<body>
        
    <div id="app">
        <main class="py-4">

            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

<script src="<?php echo e(asset('vuetify/js/vuetify.js')); ?>"></script>
</body>
</html>
<?php /**PATH /var/www/html/lcorp/web/speedB/resources/views/layouts/app.blade.php ENDPATH**/ ?>