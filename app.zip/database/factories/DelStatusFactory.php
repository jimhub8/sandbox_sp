<?php

use Faker\Generator as Faker;

$factory->define(App\DelStatus::class, function (Faker $faker) {
    return [
        //
    ];
});
