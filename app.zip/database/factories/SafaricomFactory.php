<?php

use Faker\Generator as Faker;

$factory->define(App\Safaricom::class, function (Faker $faker) {
    return [
        //
    ];
});
