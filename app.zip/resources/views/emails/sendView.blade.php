To verify 
<a href="">
	{{$user}} here
</a>

{{-- <a href="{{route('sendEmailDone', ["email"=>$user->email, "verifyToken"=>$user->verifyToken])}}">
	Click here
</a> --}}