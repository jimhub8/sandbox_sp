@extends('layouts.app')

@section('content')
<div class="container">
    <my-map></my-map>
</div>
@endsection
